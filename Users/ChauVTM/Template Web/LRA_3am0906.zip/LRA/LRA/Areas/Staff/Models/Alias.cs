﻿using System;
using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;
using LRA.Models.EntityFramework;

namespace LRA.Areas.Staff.Models
{
    public class Alias
    {
        public string aliasWord { get; set; }
        public int aliasWordTypeID { get; set; }
        public List<Dictionary> LstSynonym { get; set; }
        public List<Dictionary> LstAntonym { get; set; }
        HtmlAgilityPack.HtmlDocument HtmlDoc { get; set; }
        DemoLRAEntities Db { get; set; }
        public Alias() { }
        public Alias(string w,int typeId)
        {
            aliasWord = w;
            aliasWordTypeID = typeId;
            LstSynonym = new List<Dictionary>();
            LstAntonym = new List<Dictionary>();


            string url = "http://www.thesaurus.com/browse/" + w + "?s=t";

            HtmlWeb htmlWeb = new HtmlWeb();
            HtmlDoc = new HtmlAgilityPack.HtmlDocument();
            try
            {
                HtmlDoc = htmlWeb.Load(url);
            }
            catch (Exception)
            {
            }

            Db = new DemoLRAEntities();


        }

        bool IsExisted(string w)
        {
            Dictionary existedWord = Db.Dictionaries.FirstOrDefault(x => x.Word.Equals(w));
            return existedWord != null;
        }

        public void GetSynonyms()
        {
            
            HtmlNodeCollection synNodes = HtmlDoc.DocumentNode.SelectNodes("//div[@class='relevancy-list']//li/a/span[@class='text']");
            if (synNodes != null)
            {
                foreach (HtmlNode n in synNodes)
                {
                    if (!IsExisted(n.InnerText))
                    {
                        Dictionary synWord = new Dictionary();
                        synWord.Word = n.InnerText;
                        synWord.WordTypeId = aliasWordTypeID;
                        LstSynonym.Add(synWord);
                    }
                }
            }
        }

        public void GetAntonyms()
        {
            
            HtmlNodeCollection antNodes = HtmlDoc.DocumentNode.SelectNodes("//section[contains(@class,'antonyms')]//li/a/span[@class='text']");
            if (antNodes != null)
            {
                foreach (HtmlNode n in antNodes)
                {
                    
                    if (!IsExisted(n.InnerText))
                    {
                        Dictionary antWord = new Dictionary();
                        antWord.Word = n.InnerText;
                        if (aliasWordTypeID == 1)
                        {
                            antWord.WordTypeId = 2;
                        }
                        if (aliasWordTypeID == 2)
                        {
                            antWord.WordTypeId = 1;
                        }
                        LstAntonym.Add(antWord);
                    }
                }
            }
        }

    }
}
