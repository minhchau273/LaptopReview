﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.Mvc;
using LRA.Areas.Staff.Models;
using LRA.Models;
using LRA.Models.EntityFramework;
using Excel = Microsoft.Office.Interop.Excel;

namespace LRA.Areas.Staff.Controllers
{
    public class DictionaryController : Controller
    {
        DemoLRAEntities db = new DemoLRAEntities();
        LingoesDictionaryEntities dic = new LingoesDictionaryEntities();

        // GET: Staff/Dictionary

        #region Toan
        public ActionResult Index()
        {
            //Get Type Name, add to SelectList

            var listType = db.WordTypes.ToList().Select(w => new SelectListItem { Value = w.Id.ToString(), Text = w.Name }).ToList();
            var listClass = db.WordClasses.ToList().Select(w => new SelectListItem { Value = w.Id.ToString(), Text = w.Name }).ToList();

            ViewBag.TypeList = new SelectList(listType, "Value", "Text");
            ViewBag.ClassList = new SelectList(listClass, "Value", "Text");


            List<Dictionary> listWord = db.Dictionaries.ToList();


            return View(listWord);
        }

        public JsonResult LoadWordsList(JQueryDataTableParamModel param)
        {
            var listWord = db.Dictionaries.ToList();
            Func<Dictionary, object> sortBy = (a => a.Word);
            var rs = listWord.OrderBy(sortBy).Skip(param.iDisplayStart)
               .Where(a => string.IsNullOrEmpty(param.sSearch) || a.Word.ToUpper().Contains(param.sSearch.ToUpper())).ToList();
            var count = param.iDisplayStart;
            var rp = rs.Select(a => new IConvertible[]
                {
                    "<a class='dictionary' href='#' data-id='" + a.Id +"'>"+a.Word+"</a>"
                });

            return Json(new
            {
                sEcho = param.sEcho,
                iTotalRecords = listWord.Count(),
                iTotalDisplayRecords = listWord.Count(),
                aaData = rp
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DefinitionById(int id)
        {
            //var wordClass =
            //    db.Dictionaries.Where(a => a.Id == id).Select(b => b.WordClass).Select(c => c.Name);
            //var wordType = db.Dictionaries.Where(a => a.Id == id).Select(b => b.WordType).Select(c => c.Name).ToString();
            var word = db.Dictionaries.Find(id);
            var listSyn = db.Thesaurus.ToList().Where(a => a.DictionaryId == id && a.IsSynonym).Select(b => b.Word).ToList();
            var listAnt = db.Thesaurus.ToList().Where(a => a.DictionaryId == id && !a.IsSynonym).Select(b => b.Word).ToList();
            var definition = new DefinitionModel()
            {
                WordClass = word.WordClass.Name,
                WordType = word.WordType.Name,
                ListSynonyms = listSyn,
                ListAntonyms = listAnt
            };
            return Json(definition, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetSynonyms()
        {
            var listSynoNyms = db.Thesaurus.ToList().Where(b => b.IsSynonym).Select(a => a.Word);
            return Json(listSynoNyms, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAntonyms()
        {
            var listAntonyms = db.Thesaurus.ToList().Where(b => !b.IsSynonym).Select(a => a.Word);
            return Json(listAntonyms, JsonRequestBehavior.AllowGet);
        }
        public ActionResult InputManually()
        {
            return View();
        }

        public ActionResult ImportExcel()
        {
            return View();
        }

        public ActionResult Result()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddNewWord()
        {
            char delimiterChar = ',';
            string word = Request["word"].ToString();
            int typeId = Convert.ToInt32(Request["TypeList"]);
            int classId = Convert.ToInt32(Request["ClassList"]);
            string synonyms = Request["listSyn"].ToString();
            string antonyms = Request["listAnt"].ToString();

            var listSyn = synonyms.Split(delimiterChar);
            var listAnt = antonyms.Split(delimiterChar);

            //Check for availble word
            if (db.Dictionaries.ToList().Select(a => a.Word).Contains(word))
            {
                return RedirectToAction("Index");
            }
            else
            {
                var newWord = new Dictionary
                {
                    Word = word,
                    WordTypeId = typeId,
                    WordClassId = classId
                };

                foreach (var syn in listSyn)
                {
                    var newSyn = new Thesauru
                    {
                        Word = syn,
                        IsSynonym = true,
                        Id = db.Dictionaries.ToList().Last().Id
                    };
                    db.Thesaurus.Add(newSyn);
                }
                foreach (var ant in listAnt)
                {
                    var newAnt = new Thesauru
                    {
                        Word = ant,
                        IsSynonym = false,
                        Id = db.Dictionaries.ToList().Last().Id
                    };
                    db.Thesaurus.Add(newAnt);
                }

                db.Dictionaries.Add(newWord);
                db.SaveChanges();

            }
            return RedirectToAction("Index");
        }

        #endregion

        #region Khuong

        //public ActionResult InputManually()
        //{
        //    return View();
        //}
        //public ActionResult ImportExcel()
        //{
        //    return View();
        //}
        [HttpPost]
        // GET: /ImportExcel/
        public ActionResult ImportFile(HttpPostedFileBase fileUpload)
        {
            Excel.Application myExcel = new Excel.Application();
            Excel.Workbook myBook = null;
            Excel.Worksheet mySheet = null;
            int lastRow = 0;
            var countExist = 0;
            var count = 0;
            List<Dictionary> listDic = new List<Dictionary>();

            if (Request.Files["fileUpload"].ContentLength > 0)
            {
                string extension = System.IO.Path.GetExtension(Request.Files["fileUpload"].FileName);

                //Check valid Excel extention
                if (extension.Equals(".xlsx") || extension.Equals(".xls"))
                {

                    //Get File Upload Name
                    string fileName = System.IO.Path.GetFileName(fileUpload.FileName);


                    //combine file name and path
                    string FilePath = string.Format("{0}/{1}", Server.MapPath("~/Content/"), fileName);
                    //Delete existed path
                    if (System.IO.File.Exists(FilePath))
                    {
                        System.IO.File.Delete(FilePath);
                    }
                    //Save file to server
                    Request.Files["fileUpload"].SaveAs(FilePath);

                    //Initialize App
                    try
                    {
                        myBook = myExcel.Workbooks.Open(FilePath);
                        mySheet = myBook.Sheets[1];
                        lastRow = mySheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell).Row;

                    }
                    catch (Exception e)
                    {
                        //Clean Up
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                        //Sheet
                        Marshal.FinalReleaseComObject(mySheet);
                        //Book
                        myBook.Close(Type.Missing, Type.Missing, Type.Missing);
                        Marshal.FinalReleaseComObject(myBook);
                        //ExcelApp
                        myExcel.Quit();
                        Marshal.FinalReleaseComObject(myExcel);


                        ViewBag.Message = "Error occur when open file!" + e.StackTrace;
                        return View("ImportExcel");
                    }

                    //Read File
                    try
                    {
                        for (int index = 3; index <= lastRow; index++)
                        {
                            System.Array MyValues = (System.Array)mySheet.get_Range("B" + index.ToString(), "D" + index.ToString()).Cells.Value;
                            Dictionary newWord = new Dictionary();
                            newWord.Word = MyValues.GetValue(1, 1).ToString();
                            string wordType = MyValues.GetValue(1, 2).ToString();

                            newWord.WordTypeId = db.WordTypes.FirstOrDefault(w => w.Name.Equals(wordType)).Id;

                            //Check Spelling
                            newWord.isValid = myExcel.CheckSpelling(newWord.Word);
                            newWord.isChosen = newWord.isValid;
                            //filer 
                            Dictionary existedWord = db.Dictionaries.FirstOrDefault(w => w.Word.Equals(newWord.Word));
                            if (existedWord != null)
                            {
                                countExist++;
                            }
                            else
                            {
                                if (newWord.isValid)
                                {
                                    WordDefinition existedDic =
                                        dic.WordDefinitions.FirstOrDefault(d => d.Word.Equals(newWord.Word));
                                    if (existedDic != null)
                                    {
                                        newWord.Definition = existedDic.Definition;
                                    }
                                }
                                listDic.Add(newWord);
                                count++;

                            }
                        }

                    }
                    catch (Exception e)
                    {
                        //Clean Up
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                        //Book
                        myBook.Close(Type.Missing, Type.Missing, Type.Missing);
                        Marshal.FinalReleaseComObject(myBook);
                        //ExcelApp
                        myExcel.Quit();
                        Marshal.FinalReleaseComObject(myExcel);


                        ViewBag.Message = "Excel file is not valid format!";
                        return View("ImportExcel");
                    }

                    //Clean Up
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    //Book
                    myBook.Close(Type.Missing, Type.Missing, Type.Missing);
                    Marshal.FinalReleaseComObject(myBook);
                    //ExcelApp
                    myExcel.Quit();
                    Marshal.FinalReleaseComObject(myExcel);

                    //Creat Wordtype List name, add to select list
                    var listType = new List<SelectListItem>();
                    foreach (var w in db.WordTypes)
                    {
                        var i = new SelectListItem();
                        i.Value = w.Id.ToString();
                        i.Text = w.Name;
                        listType.Add(i);
                    }

                    ViewBag.CategoryList = new SelectList(listType, "Value", "Text");
                    ViewBag.Message = "File uploaded successfully! " + countExist + " words has already existed in database. List of new " + count + " words:";

                    return View("Result", listDic);
                }
                //Not valid Excel extension
                else
                {
                    ViewBag.Message = "Please upload an Excel file extension! (.xlsx or .xls)";
                    return View("ImportExcel");
                }
            }
            //Null file upload
            else
            {
                ViewBag.Message = "Please choose a file !";
                return View("ImportExcel");
            }
        }

        //public ActionResult Result()
        //{
        //    return View();
        //}


        [HttpPost]
        public ActionResult FindSynAndAnt(List<Dictionary> listDic)
        {
            var count = 0;
            var countExist = 0;
            var countPros = 0;
            var countCons = 0;
            List<Alias> lstAliases = new List<Alias>();
            Excel.Application myExcel = new Excel.Application();

            foreach (Dictionary word in listDic)
            {
                Dictionary newWord = new Dictionary();
                newWord.Word = word.Word;
                newWord.WordTypeId = word.WordTypeId;
                Dictionary existedWord = db.Dictionaries.FirstOrDefault(w => w.Word.Equals(newWord.Word));
                if (word.isChosen)
                {
                    //check exist
                    if (existedWord != null)
                    {
                        countExist++;
                    }
                    else
                    {
                        //add to DB
                        db.Dictionaries.Add(newWord);
                        db.SaveChanges();
                        count++;

                        //find Syn n Ant
                        try
                        {
                            if (newWord.WordTypeId == 1)
                            {
                                Alias alias = new Alias(newWord.Word, 1);
                                alias.GetAntonyms();
                                alias.GetSynonyms();
                                //Find Syn
                                foreach (Dictionary syn in alias.LstSynonym)
                                {
                                    //check spelling
                                    syn.isValid = myExcel.CheckSpelling(syn.Word);
                                    syn.isChosen = syn.isValid;
                                    //find definition
                                    if (syn.isValid)
                                    {
                                        WordDefinition existedDef =
                                        dic.WordDefinitions.FirstOrDefault(d => d.Word.Equals(syn.Word));
                                        if (existedDef != null)
                                        {
                                            syn.Definition = existedDef.Definition;
                                        }
                                    }
                                    //Count Pros
                                    countPros++;
                                }
                                //Find Ant
                                foreach (Dictionary ant in alias.LstAntonym)
                                {
                                    //check spelling
                                    ant.isValid = myExcel.CheckSpelling(ant.Word);
                                    ant.isChosen = ant.isValid;
                                    //find definition
                                    if (ant.isValid)
                                    {
                                        WordDefinition existedDef =
                                        dic.WordDefinitions.FirstOrDefault(d => d.Word.Equals(ant.Word));
                                        if (existedDef != null)
                                        {
                                            ant.Definition = existedDef.Definition;
                                        }
                                    }
                                    //Count Cons
                                    countCons++;
                                }
                                //Add to list
                                lstAliases.Add(alias);
                            }
                            if (newWord.WordTypeId == 2)
                            {
                                Alias alias = new Alias(newWord.Word, 2);
                                alias.GetAntonyms();
                                alias.GetSynonyms();
                                //Find Syn
                                foreach (Dictionary syn in alias.LstSynonym)
                                {
                                    //check spelling
                                    syn.isValid = myExcel.CheckSpelling(syn.Word);
                                    syn.isChosen = syn.isValid;
                                    //find definition
                                    if (syn.isValid)
                                    {
                                        WordDefinition existedDef =
                                        dic.WordDefinitions.FirstOrDefault(d => d.Word.Equals(syn.Word));
                                        if (existedDef != null)
                                        {
                                            syn.Definition = existedDef.Definition;
                                        }
                                    }
                                    //Count Cons
                                    countCons++;
                                }
                                //Find Ant
                                foreach (Dictionary ant in alias.LstAntonym)
                                {
                                    //check spelling
                                    ant.isValid = myExcel.CheckSpelling(ant.Word);
                                    ant.isChosen = ant.isValid;
                                    //find definition
                                    if (ant.isValid)
                                    {
                                        WordDefinition existedDef =
                                        dic.WordDefinitions.FirstOrDefault(d => d.Word.Equals(ant.Word));
                                        if (existedDef != null)
                                        {
                                            ant.Definition = existedDef.Definition;
                                        }
                                    }
                                    countPros++;
                                }
                                //Add to list
                                lstAliases.Add(alias);
                            }

                            //End try
                        }
                        catch (Exception e)
                        {
                            @ViewBag.Message = "Error when find Syn and Ant! " + e;
                            //Clean Up
                            GC.Collect();
                            GC.WaitForPendingFinalizers();
                            //ExcelApp
                            myExcel.Quit();
                            Marshal.FinalReleaseComObject(myExcel);
                            return View("ImportExcel");
                        }
                    }
                }
            }



            //Clean Up
            GC.Collect();
            GC.WaitForPendingFinalizers();
            //ExcelApp
            myExcel.Quit();
            Marshal.FinalReleaseComObject(myExcel);


            //Get Type Name, add to SelectList
            var listType = new List<SelectListItem>();
            foreach (var w in db.WordTypes)
            {
                var i = new SelectListItem();
                i.Value = w.Id.ToString();
                i.Text = w.Name;
                listType.Add(i);
            }
            ViewBag.CategoryList = new SelectList(listType, "Value", "Text");


            //Show
            ViewBag.Message = "Added " + count + " words into database. " + countExist + " words already existed. Found " + countPros + " pros and " + countCons + " cons.";
            //return View("ImportFile");
            return View("FindSynAndAnt", lstAliases);
        }

        [HttpPost]
        public ActionResult SaveToDB(List<Alias> lstAliases)
        {
            var countSyn = 0;
            var countAnt = 0;
            foreach (Alias alias in lstAliases)
            {
                foreach (Dictionary synWord in alias.LstSynonym)
                {
                    if (synWord.isChosen)
                    {
                        //Save to DB
                        db.Dictionaries.Add(synWord);
                        db.SaveChanges();
                        countSyn++;
                    }
                }
                foreach (Dictionary antWord in alias.LstAntonym)
                {
                    if (antWord.isChosen)
                    {
                        //Save to DB
                        db.Dictionaries.Add(antWord);
                        db.SaveChanges();
                        countAnt++;
                    }
                }
            }
            //Show
            ViewBag.Message = "Added " + countSyn + " synonyms and " + countAnt + " antonyms.";
            return View("ImportExcel");
        }


        #endregion

    }
}