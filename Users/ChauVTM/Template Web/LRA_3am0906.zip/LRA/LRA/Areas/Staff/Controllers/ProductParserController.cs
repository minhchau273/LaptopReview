﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HtmlAgilityPack;
using LRA.Areas.Staff.Helpers;
using LRA.Areas.Staff.Models;
using LRA.Models.EntityFramework;

namespace LRA.Areas.Staff.Controllers
{
    public class ProductParserController : Controller
    {
        DemoLRAEntities db = new DemoLRAEntities();

        // GET: Staff/ProductParser
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CreateProductParser()
        {
            return View();
        }

        public ActionResult LoadWebProduct(string parseProductLink)
        {
            HtmlNode.ElementsFlags.Remove("form");
            ParserHelper.LoadWebProduct(parseProductLink);
            TempData["link"] = parseProductLink;
            return RedirectToAction("CreateProductParser");
        }

        [HttpPost]
        public PartialViewResult LoadPreview(string parseLink, string name, string brand, string description, string image, string date, string content)
        {
            var model = new ProductParserCreator
            {
                ParseProductLink = parseLink,
                ProductNameXpath = name,
                BrandXpath = brand,
                DescriptionXpath = description,
                ImageXpath = image,
                DateXpath = date,
                ContentXpath = content,
            };

            ProductData data = new ProductData();
            try
            {            // Create Firefox browser
                var web = new HtmlWeb { UserAgent = "Mozilla/5.0 (Windows NT 6.1; rv:26.0) Gecko/20100101 Firefox/26.0" };
                //do more to get data
                var uri = new Uri(model.ParseProductLink);
                string host = uri.GetLeftPart(UriPartial.Authority);
                //load page
                System.Net.ServicePointManager.Expect100Continue = false;
                HtmlNode.ElementsFlags.Remove("form");
                var doc = web.Load(model.ParseProductLink);


                data = ParserHelper.MatchingProductDataPreview(doc, host, model.ProductNameXpath, model.BrandXpath,
                    model.DescriptionXpath, model.ImageXpath, model.DateXpath, model.ContentXpath);

                return PartialView(data);
            }
            catch (System.Net.WebException ex)
            {
                LoadPreview(parseLink, name, brand, description, image, date, content);
            }
            catch (HtmlWebException ex)
            {
                LoadPreview(parseLink, name, brand, description, image, date, content);
            }
            return PartialView();
        }


        [HttpPost]
        public RedirectToRouteResult CreateProductParser(ProductParserCreator model)
        {
            var site = new SiteInfo()
            {
                NameXpath = model.ProductNameXpath,
                BrandXpath = model.BrandXpath,
                DescriptionXpath = model.DescriptionXpath,
                ImageXpath = model.ImageXpath,
                DateXpath = model.DateXpath,
                ContentXpath = model.ContentXpath,
                Url = model.ParseProductLink
            };
            db.SiteInfoes.Add(site);
            //db.SaveChanges();
            TempData["create"] = "Create new site successfully";
            return RedirectToAction("CreateProductParser");
        }



    }
}