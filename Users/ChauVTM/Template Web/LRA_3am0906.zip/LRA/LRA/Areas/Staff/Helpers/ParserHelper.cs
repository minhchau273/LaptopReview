﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using HtmlAgilityPack;
using LRA.Areas.Staff.Models;
using LRA.CommonClass;

namespace LRA.Areas.Staff.Helpers
{
    public static class ParserHelper
    {

        public static void LoadWebProduct(string parseProductLink)
        {
            //Create agent of website
            var web = new HtmlWeb { UserAgent = "Mozilla/5.0 (Windows NT 6.1; rv:26.0) Gecko/20100101 Firefox/26.0" };
            try
            {
                //Load website
                HtmlNode.ElementsFlags.Remove("form");
                HtmlNode.ElementsFlags.Remove("option");
                var document = web.Load(parseProductLink);

                var src = new List<HtmlNode>(document.DocumentNode.Descendants().Where(x => x.Attributes["src"] != null));
                var link = new List<HtmlNode>(document.DocumentNode.Descendants().Where(x => x.Attributes["href"] != null));
                CorrectLink(src, parseProductLink, "src");
                CorrectLink(link, parseProductLink, "href");
                //Save file path
                //Remove all script
                if (parseProductLink.Contains("thietbiso.com") || parseProductLink.Contains("nguyenkim.com") || parseProductLink.Contains("viettelstore.vn"))
                {
                    document.DocumentNode.Descendants().Where(x => x.Name == "script").ToList().ForEach(x => x.Remove());
                }

                string fileName = "ProductTmp.html";
                string path = Path.Combine(ConstantManager.SavedPath, fileName);
                document.Save(path, new UTF8Encoding());
            }
            catch (System.Net.WebException ex)
            {
                LoadWebProduct(parseProductLink);
            }
            catch (HtmlWebException ex)
            {
                LoadWebProduct(parseProductLink);
            }
        }


        public static void CorrectLink(List<HtmlNode> nodes, string link, string attName)
        {
            //Take link 
            var uri = new Uri(link);
            //get host 
            string host = uri.GetLeftPart(UriPartial.Authority);
            //get path 
            String path = uri.AbsolutePath;
            if (path.EndsWith(".aspx") || path.EndsWith(".htm") || path.EndsWith(".html"))
            {
                path = path.Substring(0, path.LastIndexOf('/'));
            }
            foreach (HtmlNode node in nodes)
            {
                if (node.Attributes[attName] != null && !node.Attributes[attName].Value.StartsWith("http"))
                {
                    string tmp = "";
                    if (node.Attributes["src"] != null)
                    {
                        tmp = node.Attributes[attName].Value;
                        if (tmp.StartsWith("/"))
                        {
                            tmp = host + tmp;
                            node.Attributes[attName].Value = tmp;
                            continue;
                        }//modified for laptopgiahuy
                        else if (tmp.StartsWith("im"))
                        {
                            tmp = host + "/" + tmp;
                            node.Attributes["src"].Value = tmp;
                            continue;
                        }
                    }

                    if (path.Length > 1)
                    {
                        tmp = host + "/" + path + "/" + tmp;
                    }
                    else
                    {
                        tmp = host + "/" + tmp;
                    }
                    while (tmp.IndexOf("//") > 0)
                    {
                        tmp = tmp.Replace("//", "/");
                    }
                    tmp = tmp.Replace("http:/", "http://");
                    node.Attributes[attName].Value = tmp;
                }
            }
        }

        public static ProductData MatchingProductDataPreview(HtmlDocument doc, string host, string name, string brand,
            string description, string image, string date, string content)
        {
            var data = new ProductData();

            if (name.Length > 0)
            {
                HtmlNode nameNode = doc.DocumentNode.SelectSingleNode(name);
                if (nameNode != null)
                {
                    data.Name = nameNode.InnerText.Replace("&quot;", "");
                }
                else
                {
                    data.Name = "N/A";
                }
            }
            else
            {
                data.Name = "N/A";
            }

            if (brand.Length > 0)
            {
                HtmlNode brandNode = doc.DocumentNode.SelectSingleNode(brand);
                if (brandNode != null)
                {
                    data.Brand = brandNode.InnerText;
                }
                else
                {
                    data.Brand = "N/A";
                }
            }
            else
            {
                data.Brand = "N/A";
            }

            if (description.Length > 0)
            {
                HtmlNode descNode = doc.DocumentNode.SelectSingleNode(description);
                if (descNode != null)
                {
                    data.Description = descNode.InnerText;
                }
                else
                {
                    data.Description = "N/A";
                }
            }
            else
            {
                data.Description = "N/A";
            }

            if (image.Length > 0)
            {
                HtmlNodeCollection imageNodes = doc.DocumentNode.SelectNodes(image);
                if (imageNodes != null)
                {
                    HtmlNode imgNode = imageNodes[0];
                    data.Image = imgNode.Attributes["src"].Value;
                    data.Image = "/Areas/Content/img/noimage100.gif";
                }
                else
                {
                    data.Image = "/Areas/Content/img/noimage100.gif";
                }
            }
            else
            {
                data.Image = "/Areas/Content/img/noimage100.gif";
            }

            if (date.Length > 0)
            {
                HtmlNodeCollection dateNodes = doc.DocumentNode.SelectNodes(date);
                if (dateNodes != null)
                {
                    HtmlNode dateNode = dateNodes[0];
                    data.Date = dateNode.InnerText;
                }
                else
                {
                    data.Date = "N/A";
                }
            }
            else
            {
                data.Date = "N/A";
            }

            if (content.Length > 0)
            {
                HtmlNodeCollection contentNodes = doc.DocumentNode.SelectNodes(content);
                if (contentNodes != null)
                {
                    HtmlNode contentNode = contentNodes[0];
                    data.Content = contentNode.InnerText;
                }
                else
                {
                    data.Content = "N/A";
                }
            }
            else
            {
                data.Content = "N/A";
            }


            return data;
        }

    }
}