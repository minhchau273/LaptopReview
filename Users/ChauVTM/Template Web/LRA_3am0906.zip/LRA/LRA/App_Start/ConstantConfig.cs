﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LRA.CommonClass;

namespace LRA.App_Start
{
    public static class ConstantConfig
    {
        public static void Register(HttpServerUtility server)
        {
            ConstantManager.LogPath = server.MapPath("~/Areas/Staff/LogFiles/");
            ConstantManager.ConfigPath = server.MapPath("~/Areas/Staff/AdminConfig.xml");
            ConstantManager.SavedPath = server.MapPath("~/Areas/Staff/SavedPages");
            ConstantManager.TrainingFilePath = server.MapPath("~/UploadedExcelFiles/ProductNameTraining.txt");
            ConstantManager.TrainingFilePathForProduct = server.MapPath("~/UploadedExcelFiles/ProductNameTraining.txt");
            ConstantManager.NoResultFilePath = server.MapPath("~/Areas/Staff/LogFiles/NoResult/result.txt");
            ConstantManager.DefaultImage = server.MapPath("images/I/default.jpg");
            ConstantManager.IsParserRunning = false;
            ConstantManager.IsRecommendRunning = false;
            ConstantManager.IsUpdateRunning = false;
        }
    }
}