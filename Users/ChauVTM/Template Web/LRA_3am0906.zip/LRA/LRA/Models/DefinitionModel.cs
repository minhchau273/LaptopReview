﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LRA.Models.EntityFramework;

namespace LRA.Models
{
    public class DefinitionModel
    {
        public string WordClass { get; set; }
        public string WordType { get; set; }
        public List<string> ListSynonyms { get; set; }
        public List<string> ListAntonyms { get; set; }
    }
}