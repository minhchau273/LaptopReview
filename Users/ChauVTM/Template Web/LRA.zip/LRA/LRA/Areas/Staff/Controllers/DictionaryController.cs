﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LRA.Models;
using LRA.Models.EntityFramework;

namespace LRA.Areas.Staff.Controllers
{
    public class DictionaryController : Controller
    {
        DemoLRAEntities db = new DemoLRAEntities();

        // GET: Staff/Dictionary
        public ActionResult Index()
        {
            //Get Type Name, add to SelectList
            var listType = new List<SelectListItem>();
            foreach (var w in db.WordTypes)
            {
                var i = new SelectListItem();
                i.Value = w.Id.ToString();
                i.Text = w.Name;
                listType.Add(i);
            }
            ViewBag.CategoryList = new SelectList(listType, "Value", "Text");

            List<Dictionary> listWord = db.Dictionaries.ToList();


            return View(listWord);
        }

        public ActionResult InputManually()
        {
            return View();
        }

        public ActionResult ImportExcel()
        {
            return View();
        }

        public ActionResult Result()
        {
            return View();
        }
    }
}